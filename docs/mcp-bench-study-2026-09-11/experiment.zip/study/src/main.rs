use bytes::Bytes;
use futures_util::StreamExt;
use rmcp::model::ServerJsonRpcMessage;
use serde_json::json;
use std::{hint::black_box, io::Write, time::Instant};

struct Data {
    name: String,
    chunks: Vec<Bytes>,
    json: Vec<String>,
    messages: Vec<ServerJsonRpcMessage>,
    id: bool,
}
type Runner = fn(&Data, &tokio::runtime::Runtime, bool);
trait EventData { fn payload(&self) -> &str; }
macro_rules! event_data {
    ($lib:ident) => { impl EventData for $lib::Sse { fn payload(&self) -> &str { self.data.as_deref().unwrap() } } }
}
event_data!(v_baseline);
event_data!(v_simd);
event_data!(v_fused_direct);
event_data!(v_combo_simd);
impl EventData for sse_core::SseEvent {
    fn payload(&self) -> &str {
        match self { Self::Message(m) => &m.data, _ => panic!("unexpected control event") }
    }
}
macro_rules! runner {
    ($name:ident, $lib:ident, $stream:ident) => {
        #[inline(never)]
        fn $name(d: &Data, rt: &tokio::runtime::Runtime, with_json: bool) {
            rt.block_on(async {
                let input = tokio_stream::iter(d.chunks.iter().cloned().map(Ok::<_, std::io::Error>));
                let mut stream = $lib::$stream::new(input);
                let mut n = 0;
                while let Some(event) = stream.next().await {
                    let event = event.unwrap();
                    if with_json {
                        black_box(serde_json::from_str::<ServerJsonRpcMessage>(event.payload()).unwrap());
                    } else {
                        black_box(event);
                    }
                    n += 1;
                }
                assert_eq!(n, d.json.len());
            });
        }
    }
}
runner!(baseline, v_baseline, SseByteStream);
runner!(simd, v_simd, SseByteStream);
runner!(fused, v_fused_direct, SseByteStream);
runner!(combined, v_combo_simd, SseByteStream);
runner!(core, sse_core, SseStream);

fn json_only(d: &Data, _: &tokio::runtime::Runtime, _: bool) {
    for s in &d.json {
        black_box(serde_json::from_str::<ServerJsonRpcMessage>(black_box(s)).unwrap());
    }
}

fn encode(msg: &ServerJsonRpcMessage, id: bool, mode: usize) -> Bytes {
    match mode {
        0 => {
            let mut event = v_baseline::Sse::default().data(serde_json::to_string(msg).unwrap());
            if id { event.id = Some("session/stream/123456".into()); }
            event.into()
        }
        1 => {
            let mut event = v_encode_reserved::Sse::default().data(serde_json::to_string(msg).unwrap());
            if id { event.id = Some("session/stream/123456".into()); }
            event.into()
        }
        _ => {
            // Start with the same 128-byte capacity serde_json::to_vec uses.
            let owned_id = id.then(|| "session/stream/123456".to_owned());
            let mut out = Vec::with_capacity(128);
            out.extend_from_slice(b"data: ");
            serde_json::to_writer(&mut out, msg).unwrap();
            if let Some(id) = owned_id {
                out.extend_from_slice(b"\nid: ");
                out.extend_from_slice(id.as_bytes());
                out.extend_from_slice(b"\n\n");
            } else { out.extend_from_slice(b"\n\n"); }
            out.into()
        }
    }
}
macro_rules! encoder {
    ($name:ident, $mode:expr) => {
        fn $name(d: &Data, _: &tokio::runtime::Runtime, _: bool) {
            for msg in &d.messages { black_box(encode(black_box(msg), d.id, $mode)); }
        }
    }
}
encoder!(encode_baseline, 0);
encoder!(encode_reserved, 1);
encoder!(encode_direct, 2);

fn datasets() -> Vec<Data> {
    let progress = json!({"jsonrpc":"2.0","method":"notifications/progress","params":{"progressToken":"req-123","progress":42,"total":100,"message":"Reading repository"}});
    let chinese = json!({"jsonrpc":"2.0","id":1,"result":{"content":[{"type":"text","text":"性能分析结果：解析工具输出与资源内容。".repeat(800)}],"isError":false}});
    let ascii = json!({"jsonrpc":"2.0","id":1,"result":{"content":[{"type":"text","text":"tool output: parsed resource content. ".repeat(1200)}],"isError":false}});
    let base64 = json!({"jsonrpc":"2.0","id":1,"result":{"content":[{"type":"image","mimeType":"image/png","data":"aGVsbG8=".repeat(6000)}],"isError":false}});
    let inputs: Vec<(&str, Vec<serde_json::Value>)> = vec![
        ("progress", vec![progress.clone(); 3000]),
        ("chinese", vec![chinese.clone(); 32]),
        ("ascii", vec![ascii.clone(); 32]),
        ("base64", vec![base64; 32]),
        ("mixed", std::iter::once(chinese).chain(std::iter::repeat_n(progress, 1000)).collect()),
    ];
    let mut result = vec![];
    for (name, values) in inputs {
        for shape in ["data", "id_after", "meta_before"] {
            for chunk_mode in ["event", "1460"] {
                // Limit redundant large-body cases; retain all shapes for progress and mixed sizes.
                if !matches!(name, "progress" | "mixed") && (shape != "id_after" || chunk_mode != "1460") { continue; }
                let messages: Vec<ServerJsonRpcMessage> = values.iter().map(|v| serde_json::from_value(v.clone()).unwrap()).collect();
                let json: Vec<String> = messages.iter().map(|m| serde_json::to_string(m).unwrap()).collect();
                let wire: Vec<Bytes> = json.iter().map(|s| Bytes::from(match shape {
                    "data" => format!("data: {s}\n\n"),
                    "id_after" => format!("data: {s}\nid: session/stream/123456\n\n"),
                    _ => format!("event: message\nid: session/stream/123456\ndata: {s}\n\n"),
                })).collect();
                let chunks = if chunk_mode == "event" { wire } else {
                    let all = Bytes::from(wire.concat());
                    (0..all.len()).step_by(1460).map(|i| all.slice(i..(i+1460).min(all.len()))).collect()
                };
                result.push(Data { name: format!("{name}_{shape}_{chunk_mode}"), chunks, json, messages, id: shape != "data" });
            }
        }
    }
    result
}

fn measure(d: &Data, rt: &tokio::runtime::Runtime, group: &str, runners: &[(&str, Runner)], out: &mut std::fs::File) {
    let with_json = group == "decode_json";
    let mut iterations = vec![];
    for (_, run) in runners {
        run(d, rt, with_json);
        let t = Instant::now();
        run(d, rt, with_json);
        let n = (3_000_000 / t.elapsed().as_nanos().max(1)).clamp(1, 10000) as usize;
        for _ in 0..n { run(d, rt, with_json); }
        iterations.push(n);
    }
    let mut rng = 0x123456789u64;
    for round in 0..31 {
        let mut order: Vec<usize> = (0..runners.len()).collect();
        for i in (1..order.len()).rev() {
            rng = rng.wrapping_mul(6364136223846793005).wrapping_add(1);
            order.swap(i, (rng >> 32) as usize % (i + 1));
        }
        for index in order {
            let (name, run) = runners[index];
            let n = iterations[index];
            let t = Instant::now();
            for _ in 0..n { run(black_box(d), rt, with_json); }
            let ns = t.elapsed().as_nanos();
            writeln!(out, "{group},{},{name},{round},{n},{ns},{},{}", d.name, ns as f64 / n as f64, d.json.len()).unwrap();
        }
    }
}

fn main() {
    let rt = tokio::runtime::Builder::new_current_thread().build().unwrap();
    let output = std::env::var("STUDY_OUTPUT").unwrap_or_else(|_| "measurements.csv".into());
    let encode_only = std::env::var("STUDY_GROUP").as_deref() == Ok("encode");
    let mut out = std::fs::File::create(output).unwrap();
    writeln!(out, "group,scenario,variant,round,iterations,total_ns,ns_per_iteration,events").unwrap();
    let mut fixtures = std::fs::File::create("fixtures.jsonl").unwrap();
    for d in datasets() {
        for msg in &d.messages {
            let expected = encode(msg, d.id, 0);
            assert_eq!(expected, encode(msg, d.id, 1));
            assert_eq!(expected, encode(msg, d.id, 2));
        }
        writeln!(fixtures, "{}", json!({"name":d.name,"events":d.json.len(),"wire_bytes":d.chunks.iter().map(Bytes::len).sum::<usize>(),"chunks":d.chunks.len(),"first_json":d.json[0]})).unwrap();
        let variants: Vec<(&str, Runner)> = vec![("baseline",baseline),("simd",simd),("fused",fused),("combined",combined),("core",core)];
        if !encode_only {
            measure(&d, &rt, "decode", &variants, &mut out);
            let mut pipeline = variants;
            pipeline.push(("json_only",json_only));
            measure(&d, &rt, "decode_json", &pipeline, &mut out);
        }
        if d.name.ends_with("id_after_1460") || d.name == "progress_data_event" {
            measure(&d, &rt, "encode", &[("baseline",encode_baseline),("reserved",encode_reserved),("direct",encode_direct)], &mut out);
        }
        println!("completed {}", d.name);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn reserved_encoder_preserves_every_field_combination() {
        for value in ["", "message", "中文内容", "a\nb\r\nc"] {
            for mask in 0..16 {
                for retry in [0, 1, 10, 1000, u64::MAX] {
                    let field = |bit| (mask & bit != 0).then(|| value.to_owned());
                    let retry = (mask & 8 != 0).then_some(retry);
                    let baseline = v_baseline::Sse { event: field(1), data: field(2), id: field(4), retry };
                    let candidate = v_encode_reserved::Sse { event: field(1), data: field(2), id: field(4), retry };
                    assert_eq!(Bytes::from(baseline), Bytes::from(candidate));
                }
            }
        }
    }
}
