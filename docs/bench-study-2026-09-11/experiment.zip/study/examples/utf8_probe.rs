use std::{hint::black_box,time::Instant};
#[inline(never)] fn standard(b:&[u8])->Result<&str,std::str::Utf8Error>{std::str::from_utf8(b)}
#[inline(never)] fn vector(b:&[u8])->Result<&str,std::str::Utf8Error>{match simdutf8::basic::from_utf8(b){Ok(s)=>Ok(s),Err(_)=>std::str::from_utf8(b)}}
fn main(){
    println!("kind,bytes,round,std_ns,simd_ns,ratio");
    for kind in ["ascii","mixed","cjk"] {for size in [8,16,32,64,128,256,512,1024,4096,40000] {
        let text=match kind{"ascii"=>"x".repeat(size),"cjk"=>"你".repeat(size/3),_=>"{\"content\":\"你好，世界\"}".repeat(size/30+1)};
        let bytes=text.as_bytes();let mut end=bytes.len().min(size);while !text.is_char_boundary(end){end-=1;}let input=&bytes[..end];
        let funcs:[fn(&[u8])->Result<&str,std::str::Utf8Error>;2]=[standard,vector];
        let mut iters=[0usize;2];
        for (i,f) in funcs.iter().enumerate(){let t=Instant::now();for _ in 0..1000{black_box(f(black_box(input))).unwrap();}iters[i]=(2_000_000_000/t.elapsed().as_nanos().max(1)).clamp(100,1000000) as usize;}
        for round in 0..15 {let mut ns=[0.0;2];for i in [round%2,1-round%2]{let t=Instant::now();for _ in 0..iters[i]{black_box(funcs[i](black_box(input))).unwrap();}ns[i]=t.elapsed().as_nanos() as f64/iters[i] as f64;}println!("{kind},{end},{round},{},{},{}",ns[0],ns[1],ns[1]/ns[0]);}
    }}
}
