use std::{fmt::Write, hint::black_box, time::Instant, fs::File, io::Write as IoWrite};
use bytes::Bytes;
use futures_util::StreamExt;
use tokio::runtime::Handle;
#[derive(Debug, Clone)] struct StrError(String);
impl std::fmt::Display for StrError {fn fmt(&self,f:&mut std::fmt::Formatter<'_>)->std::fmt::Result {f.write_str(&self.0)}}
impl std::error::Error for StrError {}
struct Data {name:String,chunks:Vec<Result<Bytes,StrError>>,events:usize,borrowed:bool}
type Runner=fn(&Data,&Handle);
macro_rules! runner {($name:ident,$lib:ident)=>{
#[inline(never)]
fn $name(d:&Data,rt:&Handle) {
    rt.block_on(async {
        let mut count=0;
        if d.borrowed {
            let input=futures_util::stream::iter(d.chunks.iter().map(|b|Ok::<_,StrError>(b.as_ref().unwrap().as_ref())));
            let mut stream=$lib::SseByteStream::new(input);
            while let Some(e)=stream.next().await {black_box(e.unwrap());count+=1;}
        } else {
            let input=tokio_stream::iter(d.chunks.iter().cloned());
            let mut stream=$lib::SseByteStream::new(input);
            while let Some(e)=stream.next().await {black_box(e.unwrap());count+=1;}
        }
        assert_eq!(count,d.events);
    });
}
}}
runner!(baseline,v_baseline);
runner!(poll,v_poll);
runner!(fused_direct,v_fused_direct);
runner!(adaptive,v_adaptive);
runner!(previous_combo,v_previous_combo);
runner!(fused_dispatch,v_fused_dispatch);
runner!(reserve,v_reserve);
runner!(lazy,v_lazy);
runner!(capped,v_capped);
runner!(reuse_copy,v_reuse_copy);
runner!(comment,v_comment);
runner!(simd,v_simd);
runner!(early_comment,v_early_comment);
runner!(adaptive_copy,v_adaptive_copy);
runner!(combo,v_combo);
runner!(combo_capacity,v_combo_capacity);
runner!(combo_simd,v_combo_simd);
#[inline(never)]
fn core(d:&Data,rt:&Handle) {
    rt.block_on(async {
        let mut count=0;
        if d.borrowed {
            let input=futures_util::stream::iter(d.chunks.iter().map(|b|Ok::<_,StrError>(b.as_ref().unwrap().as_ref())));
            let mut stream=sse_core::SseStream::new(input);
            while let Some(e)=stream.next().await {black_box(e.unwrap());count+=1;}
        } else {
            let mut stream=sse_core::SseStream::new(tokio_stream::iter(d.chunks.iter().cloned()));
            while let Some(e)=stream.next().await {black_box(e.unwrap());count+=1;}
        }
        assert_eq!(count,d.events);
    });
}
fn split(b:Bytes,width:usize)->Vec<Bytes> {(0..b.len()).step_by(width).map(|i|b.slice(i..b.len().min(i+width))).collect()}
fn datasets(borrowed:bool)->Vec<Data> {
    let mut all=Vec::new();
    let mut add=|name:&str,chunks:Vec<Bytes>,events|{all.push(Data{name:name.into(),chunks:chunks.into_iter().map(Ok).collect(),events,borrowed});};
    let small=Bytes::from(b"data: {\"t\":\"a\"}\n\n".repeat(100000));
    add("small_whole",vec![small.clone()],100000);
    add("small_tcp",split(small.clone(),1460),100000);
    let e=Bytes::copy_from_slice(b"data: {\"t\":\"a\"}\n\n");
    add("small_event",(0..100000).map(|_|e.clone()).collect(),100000);
    add("small_4b",split(small,4),100000);
    let keep=Bytes::from(b": keepalive\n\n".repeat(200000));
    add("keep_whole",vec![keep.clone()],0);
    add("keep_tcp",split(keep.clone(),1460),0);
    let e=Bytes::copy_from_slice(b": keepalive\n\n");
    add("keep_event",(0..200000).map(|_|e.clone()).collect(),0);
    add("keep_4b",split(keep,4),0);
    let large=Bytes::from(format!("data: payload data: {}\n\n","word".repeat(10000)));
    add("large_event",(0..64).map(|_|large.clone()).collect(),64);
    add("large_tcp",split(Bytes::from(large.repeat(64)),1460),64);
    let mid=Bytes::from(format!("data: payload data: {}\n\n","word".repeat(1024)).repeat(256));
    add("medium_10b",split(mid,10),256);
    let mut meta=String::new();for i in 0..50000 {write!(&mut meta,"id: {i}\nevent: message\ndata: {{\"t\":\"a\"}}\n\n").unwrap();}
    add("metadata_tcp",split(Bytes::from(meta),1460),50000);
    add("multiline_tcp",split(Bytes::from(b"data: first\ndata: second\ndata: third\n\n".repeat(50000)),1460),50000);
    add("large_utf8_tcp",split(Bytes::from(format!("data: {}\n\n","你".repeat(13333)).repeat(64)),1460),64);
    let mut cycle=format!("data: {}\n\n","x".repeat(40000)).into_bytes();cycle.extend_from_slice(&b"data: x\n\n".repeat(1000));
    let mixed=Bytes::from(cycle.repeat(10));
    add("mixed_whole",vec![mixed.clone()],10010);add("mixed_tcp",split(mixed,1460),10010);
    // Force accumulation, including each small event, so single-line shortcuts cannot hide capacity policy.
    let mut cycle=format!("data: {}\ndata: tail\n\n","x".repeat(40000)).into_bytes();cycle.extend_from_slice(&b"data: x\ndata: y\n\n".repeat(1000));
    add("mixed_multiline_tcp",split(Bytes::from(cycle.repeat(10)),1460),10010);
    all
}
fn main() {
    let borrowed=std::env::var("STUDY_MODE").as_deref()==Ok("borrowed");
    let filter=std::env::var("STUDY_CASES").unwrap_or_default();
    let variant_filter=std::env::var("STUDY_VARIANTS").unwrap_or_default();
    let rounds:usize=std::env::var("STUDY_ROUNDS").unwrap_or("31".into()).parse().unwrap();
    let output=std::env::var("STUDY_OUTPUT").unwrap_or("ablation.csv".into());
    let mut out=File::create(output).unwrap();writeln!(out,"mode,scenario,variant,round,iterations,total_ns,ns_per_iteration").unwrap();
    let rt=tokio::runtime::Builder::new_current_thread().build().unwrap();
    let mut runners:Vec<(&str,Runner)>=vec![
("baseline",baseline),
("poll",poll),
("fused_direct",fused_direct),
("adaptive",adaptive),
("previous_combo",previous_combo),
("fused_dispatch",fused_dispatch),
("reserve",reserve),
("lazy",lazy),
("capped",capped),
("reuse_copy",reuse_copy),
("comment",comment),
("simd",simd),

    ("early_comment",early_comment),
    ("adaptive_copy",adaptive_copy),
    ("combo",combo),
    ("combo_capacity",combo_capacity),
    ("combo_simd",combo_simd),
    ("core",core)];
    runners.retain(|(n,_)|variant_filter.is_empty()||variant_filter.split(',').any(|x|x==*n));
    let mut random=12345678u64;
    for data in datasets(borrowed) {
        if !filter.is_empty()&&!filter.split(',').any(|x|x==data.name){continue;}
        let mut iterations=Vec::new();
        for (_,f) in &runners {
            f(&data,rt.handle());
            let t=Instant::now();f(&data,rt.handle());let elapsed=t.elapsed().as_nanos() as u64;
            let n=(5_000_000/elapsed.max(1)).clamp(1,10000) as usize;
            for _ in 0..n {f(&data,rt.handle());}
            iterations.push(n);
        }
        for round in 0..rounds {
            let mut order:Vec<_>=(0..runners.len()).collect();
            for i in (1..order.len()).rev() {random=random.wrapping_mul(6364136223846793005).wrapping_add(1);order.swap(i,(random>>32) as usize%(i+1));}
            for index in order {
                let (name,f)=runners[index];let n=iterations[index];let t=Instant::now();
                for _ in 0..n {f(black_box(&data),rt.handle());}
                let ns=t.elapsed().as_nanos();
                writeln!(out,"{},{},{},{},{},{},{}",if borrowed{"borrowed_ready"}else{"bytes_tokio"},data.name,name,round,n,ns,ns as f64/n as f64).unwrap();
            }
        }
        println!("completed {} / {} variants x {} rounds",data.name,runners.len(),rounds);
    }
}
