from pathlib import Path
import os,subprocess
p=Path(__file__).resolve().parent
env=os.environ.copy();env['CARGO_TARGET_DIR']=os.environ.get('CARGO_TARGET_DIR',str(p/'target'))
for i,order in enumerate(['core,prototype,baseline','baseline,core,prototype','prototype,baseline,core'],1):
 env['BENCH_ORDER']=order;env['CRITERION_HOME']=str(p/'criterion'/str(i))
 with (p/f'verify-{i}.log').open('w') as log:
  result=subprocess.run(['taskset','-c',os.environ.get('STUDY_CPU','2'),'cargo','bench','--offline','--bench','bench','--','--sample-size','40','--warm-up-time','0.15','--measurement-time','0.8','--noplot'],cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('round',i,'exit',result.returncode,flush=True)
 if result.returncode: break
