This snapshot contains the 2026-09-11 investigation. No runtime downloads or external services are used by the benchmarks.

Run from study/ on Linux, using the pinned Cargo.lock and a populated Cargo cache (cargo fetch --locked if needed).

- Screening: taskset -c 2 cargo run --offline --release --example ablation
- Selection: STUDY_VARIANTS=baseline,simd,fused_dispatch,core STUDY_CASES=small_tcp,large_utf8_tcp STUDY_OUTPUT=repeat.csv taskset -c 2 cargo run --offline --release --example ablation
- Borrowed input: set STUDY_MODE=borrowed.
- Three Criterion rounds: python3 verify.py
- Optional environment: CARGO_TARGET_DIR and STUDY_CPU (verify.py only; default CPU 2).
- Output comparison: python3 summarize.py repeat.csv
- Equivalence: cargo test --offline --test equivalence
- Combined candidate parser tests: cargo test --offline --manifest-path candidate-project/Cargo.toml --test test_bytes_parse --test test_encode_body --test equivalence

Interpret paired screening separately from Criterion. Source and input types affect code generation. This is research code, not a proposal to merge all changes. The combined candidate has known small regressions in keepalive and multiline scenarios; use the report to choose individual patches.
