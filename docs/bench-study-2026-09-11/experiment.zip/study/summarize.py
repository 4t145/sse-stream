from pathlib import Path
import sys,csv,statistics,collections,json,random
rows=list(csv.DictReader(Path(sys.argv[1]).open()));d=collections.defaultdict(dict)
for r in rows:d[(r['scenario'],r['variant'])][int(r['round'])]=float(r['ns_per_iteration'])
scenarios=list(dict.fromkeys(r['scenario'] for r in rows));variants=list(dict.fromkeys(r['variant'] for r in rows))
print('Ratios vs baseline: below 1 is faster; paired median across rounds.')
print('scenario'.ljust(22)+' '.join(v[:12].rjust(12) for v in variants if v!='baseline'))
for sc in scenarios:
 base=d[(sc,'baseline')]
 out=[]
 for v in variants:
  if v=='baseline':continue
  ratios=[n/base[i] for i,n in d[(sc,v)].items() if i in base]
  out.append(f'{statistics.median(ratios):12.3f}' if ratios else '           -')
 print(sc.ljust(22)+''.join(out))
