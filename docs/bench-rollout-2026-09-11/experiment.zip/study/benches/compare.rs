use bytes::Bytes;
use criterion::{criterion_group, criterion_main, BatchSize, Criterion};
use futures_util::StreamExt;
use std::{hint::black_box, time::Duration};
#[path = "../src/scenarios.rs"]
mod scenarios;

fn compare(c: &mut Criterion) {
    let rt = tokio::runtime::Builder::new_current_thread().build().unwrap();
    let order = std::env::var("STUDY_ORDER").unwrap_or_else(|_| "baseline,step1,step2,core".into());
    let filter = std::env::var("STUDY_CASES").unwrap_or_default();
    for case in scenarios::decode_cases() {
        if !filter.is_empty() && !filter.split(',').any(|name| name == case.name) { continue; }
        let mut group = c.benchmark_group(&case.name);
        group.throughput(criterion::Throughput::Bytes(case.chunks.iter().map(Bytes::len).sum::<usize>() as u64));
        macro_rules! run {
            ($name:expr, $lib:ident, $stream:ident) => {{
                group.bench_function($name, |b| b.to_async(rt.handle()).iter(|| async {
                    let input = tokio_stream::iter(case.chunks.iter().cloned().map(Ok::<_, std::io::Error>));
                    let mut stream = $lib::$stream::new(input);
                    let mut n = 0;
                    while let Some(event) = stream.next().await { black_box(event.unwrap()); n += 1; }
                    assert_eq!(n, case.events);
                }));
            }}
        }
        for name in order.split(',') {
            match name {
                "baseline" => run!("baseline", v_baseline, SseByteStream),
                "step1" => run!("step1", v_step1, SseByteStream),
                "step2" => run!("step2", v_step2, SseByteStream),
                "core" => run!("core", sse_core, SseStream),
                _ => panic!("unknown variant"),
            }
        }
        group.finish();
    }
    for case in scenarios::encode_cases() {
        if !filter.is_empty() && !filter.split(',').any(|name| name == case.name) { continue; }
        let mut group = c.benchmark_group(format!("encode_{}",case.name));
        macro_rules! run {
            ($name:expr, $lib:ident) => {{
                let event = $lib::Sse {event:case.event.clone(),data:Some(case.data.clone()),id:case.id.clone(),retry:case.retry};
                group.bench_function($name, |b| b.iter_batched(|| event.clone(), |event| black_box(Bytes::from(event)), BatchSize::LargeInput));
            }}
        }
        for name in order.split(',') {
            match name {
                "baseline" => run!("baseline", v_baseline),
                "step1" => run!("step1", v_step1),
                "step2" => run!("step2", v_step2),
                "core" => {},
                _ => panic!("unknown variant"),
            }
        }
        group.finish();
    }
}
criterion_group! {
    name = benches;
    config = Criterion::default().sample_size(40).warm_up_time(Duration::from_millis(150)).measurement_time(Duration::from_millis(700)).nresamples(10000);
    targets = compare,
}
criterion_main!(benches);
