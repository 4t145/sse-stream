import csv, collections, statistics, sys
samples = collections.defaultdict(dict)
for row in csv.DictReader(open(sys.argv[1])):
    samples[row['mode'], row['scenario'], row['variant']][row['round']] = float(row['ns_per_iteration'])
writer = csv.writer(sys.stdout)
writer.writerow(['mode', 'scenario', 'variant', 'ratio_median', 'ratio_p10', 'ratio_p90'])
for (mode, scenario, variant), values in sorted(samples.items()):
    baseline = samples.get((mode, scenario, 'baseline'), {})
    if not baseline: continue
    ratios = sorted(value / baseline[round] for round, value in values.items())
    writer.writerow([mode, scenario, variant, statistics.median(ratios), ratios[len(ratios)//10], ratios[(len(ratios)*9)//10]])
