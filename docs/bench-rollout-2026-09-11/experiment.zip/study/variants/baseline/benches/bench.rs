//! End-to-end stream benchmarks comparing this crate with `sse-core` across
//! event shapes and input fragmentation patterns.
//!
//! All comparison workloads produce the same number of logical message events
//! in both implementations. `retry` is deliberately excluded because
//! `sse-core` yields it as a standalone event while `sse-stream` attaches it to
//! the next [`sse_stream::Sse`], which makes a throughput ratio misleading.
//!
//! Run the full suite with `cargo bench`, or use `cargo bench -- --quick` while
//! iterating locally.

use std::{fmt::Write, hint::black_box, time::Duration};

use bytes::Bytes;
use criterion::{criterion_group, criterion_main, Criterion};
use thiserror::Error;
use tokio_stream::StreamExt;

use sse_core::SseStream as SseCoreStream;

const LARGE_PAYLOAD_SIZE: usize = 40_000;
const MEDIUM_PAYLOAD_SIZE: usize = 4096;
const TCP_CHUNK_SIZE: usize = 1460;
const TINY_CHUNK_SIZE: usize = 10;
const PREFIX_SPLIT_CHUNK_SIZE: usize = 4;

const LARGE_EVENT_COUNT: usize = 64;
const MEDIUM_EVENT_COUNT: usize = 256;
const SMALL_EVENT_COUNT: usize = 100_000;
const STRUCTURED_EVENT_COUNT: usize = 50_000;
const KEEPALIVE_COUNT: usize = 200_000;

const SMALL_DATA_EVENT: &[u8] = b"data: {\"t\":\"a\"}\n\n";
const MULTILINE_DATA_EVENT: &[u8] = b"data: first\ndata: second\ndata: third\n\n";
const KEEPALIVE: &[u8] = b": keepalive\n\n";

fn split_chunks(bytes: &Bytes, chunk_size: usize) -> Vec<Bytes> {
    (0..bytes.len())
        .step_by(chunk_size)
        .map(|i| bytes.slice(i..bytes.len().min(i + chunk_size)))
        .collect()
}

fn repeated_payload(event: &[u8], event_count: usize) -> Bytes {
    Bytes::from(event.repeat(event_count))
}

fn repeated_event_chunks(event: &[u8], event_count: usize) -> Vec<Bytes> {
    let event = Bytes::copy_from_slice(event);
    (0..event_count).map(|_| event.clone()).collect()
}

fn generate_data_event(payload_size: usize) -> Bytes {
    let payload = "word".repeat(payload_size / 4);
    Bytes::from(format!("data: payload data: {payload}\n\n"))
}

fn generate_metadata_payload(event_count: usize) -> Bytes {
    let mut payload = String::with_capacity(52 * event_count);
    for i in 0..event_count {
        write!(
            &mut payload,
            "id: {i}\nevent: message\ndata: {{\"t\":\"a\"}}\n\n"
        )
        .unwrap();
    }
    Bytes::from(payload)
}

#[derive(Debug, Clone, Error)]
#[error("{0}")]
struct StrError(String);

fn bench_async_cmp(
    c: &mut Criterion,
    group_name: &str,
    chunks: Vec<Bytes>,
    expected_events: usize,
) {
    let payload_len: usize = chunks.iter().map(Bytes::len).sum();
    let chunks: Vec<Result<_, StrError>> = chunks.into_iter().map(Ok).collect();

    let mut group = c.benchmark_group(group_name);
    group.throughput(criterion::Throughput::Bytes(payload_len as u64));

    let runtime = tokio::runtime::Builder::new_current_thread()
        .build()
        .unwrap();

    group.bench_function("sse_core", |b| {
        b.to_async(runtime.handle()).iter(|| async {
            let mut stream = SseCoreStream::new(tokio_stream::iter(chunks.iter().cloned()));
            let mut event_count = 0;

            while let Some(event) = stream.next().await {
                black_box(event.expect("sse-core parse error"));
                event_count += 1;
            }

            assert_eq!(event_count, expected_events);
        })
    });

    group.bench_function("sse_stream", |b| {
        b.to_async(runtime.handle()).iter(|| async {
            let mut stream =
                sse_stream::SseByteStream::new(tokio_stream::iter(chunks.iter().cloned()));
            let mut event_count = 0;

            while let Some(event) = stream.next().await {
                black_box(event.expect("sse-stream parse error"));
                event_count += 1;
            }

            assert_eq!(event_count, expected_events);
        })
    });

    group.finish();
}

fn bench_small_data(c: &mut Criterion) {
    let payload = repeated_payload(SMALL_DATA_EVENT, SMALL_EVENT_COUNT);

    bench_async_cmp(
        c,
        "small_data_whole_stream_chunk",
        vec![payload.clone()],
        SMALL_EVENT_COUNT,
    );
    bench_async_cmp(
        c,
        "small_data_tcp_chunks",
        split_chunks(&payload, TCP_CHUNK_SIZE),
        SMALL_EVENT_COUNT,
    );
    bench_async_cmp(
        c,
        "small_data_event_chunks",
        repeated_event_chunks(SMALL_DATA_EVENT, SMALL_EVENT_COUNT),
        SMALL_EVENT_COUNT,
    );
    bench_async_cmp(
        c,
        "small_data_4b_chunks",
        split_chunks(&payload, PREFIX_SPLIT_CHUNK_SIZE),
        SMALL_EVENT_COUNT,
    );
}

fn bench_structured_events(c: &mut Criterion) {
    let metadata = generate_metadata_payload(STRUCTURED_EVENT_COUNT);
    bench_async_cmp(
        c,
        "metadata_events_tcp_chunks",
        split_chunks(&metadata, TCP_CHUNK_SIZE),
        STRUCTURED_EVENT_COUNT,
    );

    let multiline = repeated_payload(MULTILINE_DATA_EVENT, STRUCTURED_EVENT_COUNT);
    bench_async_cmp(
        c,
        "multiline_data_tcp_chunks",
        split_chunks(&multiline, TCP_CHUNK_SIZE),
        STRUCTURED_EVENT_COUNT,
    );
}

fn bench_keepalives(c: &mut Criterion) {
    let payload = repeated_payload(KEEPALIVE, KEEPALIVE_COUNT);

    bench_async_cmp(c, "keepalive_whole_stream_chunk", vec![payload.clone()], 0);
    bench_async_cmp(
        c,
        "keepalive_tcp_chunks",
        split_chunks(&payload, TCP_CHUNK_SIZE),
        0,
    );
    bench_async_cmp(
        c,
        "keepalive_line_chunks",
        repeated_event_chunks(KEEPALIVE, KEEPALIVE_COUNT),
        0,
    );
    bench_async_cmp(
        c,
        "keepalive_4b_chunks",
        split_chunks(&payload, PREFIX_SPLIT_CHUNK_SIZE),
        0,
    );
}

fn bench_large_data(c: &mut Criterion) {
    let event = generate_data_event(LARGE_PAYLOAD_SIZE);
    let payload = Bytes::from(event.repeat(LARGE_EVENT_COUNT));

    bench_async_cmp(
        c,
        "large_data_event_chunks",
        (0..LARGE_EVENT_COUNT).map(|_| event.clone()).collect(),
        LARGE_EVENT_COUNT,
    );
    bench_async_cmp(
        c,
        "large_data_tcp_chunks",
        split_chunks(&payload, TCP_CHUNK_SIZE),
        LARGE_EVENT_COUNT,
    );
}

fn bench_fragmented_medium_data(c: &mut Criterion) {
    let event = generate_data_event(MEDIUM_PAYLOAD_SIZE);
    let payload = Bytes::from(event.repeat(MEDIUM_EVENT_COUNT));

    bench_async_cmp(
        c,
        "medium_data_10b_chunks",
        split_chunks(&payload, TINY_CHUNK_SIZE),
        MEDIUM_EVENT_COUNT,
    );
}

criterion_group! {
    name = benches;
    config = Criterion::default()
        .sample_size(100)
        .measurement_time(Duration::from_secs(10));
    targets =
        bench_small_data,
        bench_structured_events,
        bench_keepalives,
        bench_large_data,
        bench_fragmented_medium_data,
}
criterion_main!(benches);
