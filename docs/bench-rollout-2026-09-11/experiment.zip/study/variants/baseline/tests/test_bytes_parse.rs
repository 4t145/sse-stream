use bytes::{Buf, Bytes};
use futures_util::StreamExt;
use http_body::Frame;
use http_body_util::{Full, StreamBody};
use sse_stream::{Sse, SseByteStream, SseStream};

struct ChainedFrameBody {
    sent: bool,
    first: &'static [u8],
    second: &'static [u8],
}

impl http_body::Body for ChainedFrameBody {
    type Data = bytes::buf::Chain<Bytes, Bytes>;
    type Error = std::convert::Infallible;

    fn poll_frame(
        mut self: std::pin::Pin<&mut Self>,
        _: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Result<Frame<Self::Data>, Self::Error>>> {
        if self.sent {
            return std::task::Poll::Ready(None);
        }
        self.sent = true;
        let chained = bytes::Buf::chain(
            Bytes::from_static(self.first),
            Bytes::from_static(self.second),
        );
        std::task::Poll::Ready(Some(Ok(Frame::data(chained))))
    }
}

#[tokio::test]
async fn test_multi_segment_buf_frame_not_truncated() {
    // The full frame, once flattened, is a single complete SSE event.
    // If `chunk()` is used naively, only the first segment ("data: hel")
    // is read and the message is silently dropped at end-of-stream.
    let body = ChainedFrameBody {
        sent: false,
        first: b"data: hel",
        second: b"lo\n\n",
    };
    let mut sse_body = SseStream::new(body);
    let mut out = Vec::new();
    while let Some(sse) = sse_body.next().await {
        out.push(sse.expect("parse error"));
    }
    assert_eq!(
        out,
        vec![Sse {
            event: None,
            data: Some("hello".into()),
            id: None,
            retry: None,
        }],
        "multi-segment Buf frame must be fully consumed"
    );
}

#[tokio::test]
async fn test_multi_segment_buf_from_byte_stream_not_truncated() {
    let data = Bytes::from_static(b"data: hel").chain(Bytes::from_static(b"lo\n\n"));
    let stream = futures_util::stream::iter([Ok::<_, std::convert::Infallible>(data)]);
    let mut events = SseByteStream::new(stream);

    assert_eq!(events.next().await.unwrap().unwrap(), data_only("hello"));
    assert!(events.next().await.is_none());
}

#[tokio::test]
async fn test_multiple_events_retained_from_one_byte_buffer() {
    let data = Bytes::from_static(b"data: one\n\ndata: two\n\n");
    let stream =
        futures_util::stream::iter([Ok(data), Err(std::io::Error::other("end-of-test error"))]);
    let mut events = SseByteStream::new(stream);

    assert_eq!(events.next().await.unwrap().unwrap(), data_only("one"));
    assert_eq!(events.next().await.unwrap().unwrap(), data_only("two"));
    assert!(matches!(
        events.next().await,
        Some(Err(sse_stream::Error::Body(_)))
    ));
    assert!(events.next().await.is_none());
}

#[tokio::test]
async fn test_multiple_events_retained_from_one_body_frame() {
    let body = Full::new(Bytes::from_static(b"data: one\n\ndata: two\n\n"));
    let mut events = SseStream::new(body);

    assert_eq!(events.next().await.unwrap().unwrap(), data_only("one"));
    assert_eq!(events.next().await.unwrap().unwrap(), data_only("two"));
    assert!(events.next().await.is_none());
}

#[tokio::test]
async fn test_event_split_across_many_immediately_ready_fragments() {
    const SEGMENTS: usize = 10_000;
    let mut fragments: Vec<&'static [u8]> = Vec::with_capacity(SEGMENTS + 2);
    fragments.push(b"data: ");
    fragments.extend((0..SEGMENTS).map(|_| b"x".as_slice()));
    fragments.push(b"\n\n");

    let events = collect_from_chunks(fragments).await;
    assert_eq!(events.len(), 1);
    assert_eq!(events[0].data.as_deref().map(str::len), Some(SEGMENTS));
}

#[tokio::test]
async fn test_data_prefix_split_at_every_byte() {
    let cases: Vec<Vec<&'static [u8]>> = vec![
        vec![b"d", b"ata: hello\n\n"],
        vec![b"da", b"ta: hello\n\n"],
        vec![b"dat", b"a: hello\n\n"],
        vec![b"data", b": hello\n\n"],
        vec![b"data:", b" hello\n\n"],
    ];

    for chunks in cases {
        assert_eq!(collect_from_chunks(chunks).await, vec![data_only("hello")]);
    }
}

#[tokio::test]
async fn test_bom_split_across_segments_of_one_frame() {
    let data = Bytes::from_static(b"\xEF")
        .chain(Bytes::from_static(b"\xBB"))
        .chain(Bytes::from_static(b"\xBF"))
        .chain(Bytes::from_static(b"data: hello\n\n"));
    let mut events = SseStream::new(Full::new(data));

    assert_eq!(events.next().await.unwrap().unwrap(), data_only("hello"),);
    assert!(events.next().await.is_none());
}

#[tokio::test]
async fn test_crlf_split_across_segments_of_one_frame() {
    let data = Bytes::from_static(b"data: hello\r")
        .chain(Bytes::from_static(b"\n"))
        .chain(Bytes::from_static(b"data: world\n\n"));
    let mut events = SseStream::new(Full::new(data));

    assert_eq!(
        events.next().await.unwrap().unwrap(),
        data_only("hello\nworld"),
    );
    assert!(events.next().await.is_none());
}

#[tokio::test]
async fn test_empty_chunk_between_split_crlf() {
    let out = collect_from_chunks(vec![b"data: hello\r", b"", b"\ndata: world\n\n"]).await;
    assert_eq!(out, vec![data_only("hello\nworld")]);
}

async fn collect_from_full(data: &[u8]) -> Vec<Sse> {
    let body = Full::<Bytes>::from(data.to_vec());
    let mut sse_body = SseStream::new(body);
    let mut out = Vec::new();
    while let Some(sse) = sse_body.next().await {
        out.push(sse.expect("parse error"));
    }
    out
}

async fn collect_from_chunks(chunks: Vec<&'static [u8]>) -> Vec<Sse> {
    let stream = futures_util::stream::iter(
        chunks
            .into_iter()
            .map(|c| Ok::<_, std::convert::Infallible>(Bytes::from_static(c))),
    );
    let mut sse_body = SseByteStream::new(stream);
    let mut out = Vec::new();
    while let Some(sse) = sse_body.next().await {
        out.push(sse.expect("parse error"));
    }
    out
}

fn data_only(s: &str) -> Sse {
    Sse {
        event: None,
        data: Some(s.to_owned()),
        id: None,
        retry: None,
    }
}

#[tokio::test]
async fn test_bytes_parse() {
    let bytes = include_bytes!("data/test_stream.sse");
    let body = Full::<Bytes>::from(bytes.to_vec());

    let mut sse_body = sse_stream::SseStream::new(body);
    while let Some(sse) = sse_body.next().await {
        println!("{:?}", sse.unwrap());
    }
}

#[tokio::test]
async fn test_bom_header_at_start() {
    let sse_data = b"\xEF\xBB\xBFdata: hello\n\n";
    let body = Full::<Bytes>::from(sse_data.to_vec());
    let mut sse_body = sse_stream::SseStream::new(body);

    let sse = sse_body
        .next()
        .await
        .expect("Should have one SSE event")
        .unwrap();
    assert_eq!(sse.data, Some("hello".to_string()));
}

#[tokio::test]
async fn test_line_break_crlf() {
    let out = collect_from_full(b"data: a\r\ndata: b\r\n\r\n").await;
    assert_eq!(out, vec![data_only("a\nb")]);
}

#[tokio::test]
async fn test_line_break_cr_only() {
    let out = collect_from_full(b"data: a\rdata: b\r\r").await;
    assert_eq!(out, vec![data_only("a\nb")]);
}

#[tokio::test]
async fn test_line_break_mixed() {
    // `\n`, `\r`, and `\r\n` interleaved.
    let payload: &[u8] = b"data: one\r\ndata: two\rdata: three\n\r\n";
    let out = collect_from_full(payload).await;
    assert_eq!(out, vec![data_only("one\ntwo\nthree")]);
}

#[tokio::test]
async fn test_cr_lf_split_across_chunks() {
    // Original payload:  "data: hello\r\ndata: world\n\n"
    // Split:             "data: hello\r"  +  "\ndata: world\n\n"
    let out = collect_from_chunks(vec![b"data: hello\r", b"\ndata: world\n\n"]).await;
    assert_eq!(out, vec![data_only("hello\nworld")]);
}

#[tokio::test]
async fn test_cr_then_non_lf_across_chunks() {
    // Original: "data: a\rdata: b\n\n"  =>  one event with "a\nb"
    let out = collect_from_chunks(vec![b"data: a\r", b"data: b\n\n"]).await;
    assert_eq!(out, vec![data_only("a\nb")]);
}

#[tokio::test]
async fn test_cr_then_cr_across_chunks() {
    // Original: "data: a\r\rdata: b\n\n" -> ["data: a", "", "data: b", ""]
    // -> dispatch event {data:"a"} on the second "", then "data: b" continues a new event
    let out = collect_from_chunks(vec![b"data: a\r", b"\rdata: b\n\n"]).await;
    assert_eq!(out, vec![data_only("a"), data_only("b")]);
}

#[tokio::test]
async fn test_dispatch_boundary_split_at_cr() {
    // "data: x\r\n\r\n" split as "data: x\r\n\r" + "\n"
    // Expected: one event {data: "x"}.
    let out = collect_from_chunks(vec![b"data: x\r\n\r", b"\n"]).await;
    assert_eq!(out, vec![data_only("x")]);
}

#[tokio::test]
async fn test_multiple_consecutive_cr() {
    // "data: a\r\r\r" -> lines: "data: a", "", ""  -> dispatch after first empty.
    let out = collect_from_full(b"data: a\r\r\r").await;
    assert_eq!(out, vec![data_only("a")]);
}

#[tokio::test]
async fn test_comment_lines() {
    let out = collect_from_full(b": this is a comment\ndata: hi\n: another\n\n").await;
    assert_eq!(out, vec![data_only("hi")]);
}

#[tokio::test]
async fn test_fragmented_comment_lines() {
    let out = collect_from_chunks(vec![b": ke", b"ep", b"alive\n", b"\n"]).await;
    assert!(out.is_empty());

    let out = collect_from_chunks(vec![b": comm", b"ent\ndata: before\n\n"]).await;
    assert_eq!(out, vec![data_only("before")]);

    let out = collect_from_chunks(vec![b"data: after\n: comm", b"ent\n\n"]).await;
    assert_eq!(out, vec![data_only("after")]);
}

#[tokio::test]
async fn test_empty_data_field() {
    let out = collect_from_full(b"data:\n\n").await;
    assert_eq!(out, vec![data_only("")]);
}

#[tokio::test]
async fn test_two_empty_data_lines_join_with_newline() {
    let out = collect_from_full(b"data:\ndata:\n\n").await;
    assert_eq!(out, vec![data_only("\n")]);
}

#[tokio::test]
async fn test_only_one_leading_space_stripped() {
    let out = collect_from_full(b"data:  hello\n\n").await;
    // The first space is stripped, the second is preserved.
    assert_eq!(out, vec![data_only(" hello")]);
}

#[tokio::test]
async fn test_id_with_null_byte_ignored() {
    let payload: &[u8] = b"id: ab\x00cd\ndata: x\n\n";
    let stream = futures_util::stream::iter(std::iter::once(Ok::<_, std::convert::Infallible>(
        Frame::data(Bytes::from_static(payload)),
    )));
    let body = StreamBody::new(stream);
    let mut sse_body = SseStream::new(body);
    let mut out = Vec::new();
    while let Some(sse) = sse_body.next().await {
        out.push(sse.expect("parse error"));
    }
    assert_eq!(out, vec![data_only("x")], "id with NULL must be ignored");
}

#[tokio::test]
async fn test_incomplete_trailing_event_discarded() {
    // No empty line after the second event.
    let out = collect_from_full(b"data: complete\n\ndata: incomplete\n").await;
    assert_eq!(out, vec![data_only("complete")]);
}

#[tokio::test]
async fn test_multiple_events_split_chunks() {
    let out = collect_from_chunks(vec![
        b"event: a\ndata: 1\n",
        b"\nevent: b\nda",
        b"ta: 2\n\n",
    ])
    .await;
    assert_eq!(
        out,
        vec![
            Sse {
                event: Some("a".into()),
                data: Some("1".into()),
                ..Default::default()
            },
            Sse {
                event: Some("b".into()),
                data: Some("2".into()),
                ..Default::default()
            },
        ]
    );
}

#[tokio::test]
async fn test_bom_split_across_chunks() {
    let chunk1 = Bytes::from_static(b"\xEF");
    let chunk2 = Bytes::from_static(b"\xBB\xBFdata: hello\n\n");

    let body = {
        let stream = futures_util::stream::iter(
            [chunk1, chunk2]
                .into_iter()
                .map(|chunk| Ok::<_, std::convert::Infallible>(Frame::data(chunk))),
        );
        StreamBody::new(stream)
    };
    let mut sse_body = sse_stream::SseStream::new(body);

    let sse = sse_body
        .next()
        .await
        .expect("Should have one SSE event")
        .unwrap();
    assert_eq!(sse.data, Some("hello".to_string()));
}

#[tokio::test]
async fn test_fragmented_data_line_split_mid_utf8_char() {
    // The first fragment already carries the `data:` prefix, so the value
    // streams into the data buffer directly; the multi-byte character 你 is
    // split across two fragments and must be validated only once the line
    // completes.
    let out = collect_from_chunks(vec![b"data: \xe4", b"\xbd\xa0 ok\n\n"]).await;
    assert_eq!(out, vec![data_only("你 ok")]);
}

#[tokio::test]
async fn test_fragmented_data_line_five_byte_chunks() {
    // 5-byte fragments engage the direct-append fast path (`data:` fits) and
    // are guaranteed to split some multi-byte characters.
    const PAYLOAD: &str = "data: 你好世界🦀\n\n";
    let out = collect_from_chunks(PAYLOAD.as_bytes().chunks(5).collect()).await;
    assert_eq!(out, vec![data_only("你好世界🦀")]);
}

#[tokio::test]
async fn test_fragmented_data_line_empty_first_fragment() {
    let out = collect_from_chunks(vec![b"data:", b"payload\n\n"]).await;
    assert_eq!(out, vec![data_only("payload")]);
}

#[tokio::test]
async fn test_fragmented_data_line_does_not_leak_into_next_event() {
    // First event goes through the direct-append path, the second through
    // the buffered path (`da` does not carry the full prefix); both must
    // come out intact.
    let out = collect_from_chunks(vec![b"data: first-", b"part2\n\nda", b"ta: second\n\n"]).await;
    assert_eq!(out, vec![data_only("first-part2"), data_only("second")]);
}

#[tokio::test]
async fn test_invalid_utf8_in_fragmented_data_line() {
    let stream = futures_util::stream::iter(
        [&b"data: \xff"[..], b"\xfe\n\n"]
            .into_iter()
            .map(|c| Ok::<_, std::convert::Infallible>(Frame::data(Bytes::from_static(c)))),
    );
    let body = StreamBody::new(stream);
    let mut sse_body = SseStream::new(body);

    let first = sse_body.next().await.expect("stream ended early");
    assert!(
        matches!(first, Err(sse_stream::Error::Utf8Parse(_))),
        "expected Utf8Parse error, got {first:?}"
    );
}
