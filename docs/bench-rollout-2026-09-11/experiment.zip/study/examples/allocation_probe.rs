use std::{alloc::{GlobalAlloc, Layout, System}, pin::pin, sync::atomic::{AtomicBool, AtomicUsize, Ordering}, task::{Context, Poll}};
use bytes::Bytes;
use futures_util::{Stream, StreamExt};
static ENABLED: AtomicBool = AtomicBool::new(false);
static ALLOCS: AtomicUsize = AtomicUsize::new(0);
static REALLOCS: AtomicUsize = AtomicUsize::new(0);
static REQUESTED: AtomicUsize = AtomicUsize::new(0);
struct Count;
unsafe impl GlobalAlloc for Count {
    unsafe fn alloc(&self, l: Layout) -> *mut u8 {
        if ENABLED.load(Ordering::Relaxed) { ALLOCS.fetch_add(1, Ordering::Relaxed); REQUESTED.fetch_add(l.size(), Ordering::Relaxed); }
        System.alloc(l)
    }
    unsafe fn dealloc(&self, p: *mut u8, l: Layout) { System.dealloc(p,l) }
    unsafe fn realloc(&self, p: *mut u8, l: Layout, size: usize) -> *mut u8 {
        if ENABLED.load(Ordering::Relaxed) { REALLOCS.fetch_add(1, Ordering::Relaxed); REQUESTED.fetch_add(size, Ordering::Relaxed); }
        System.realloc(p,l,size)
    }
}
#[global_allocator] static A: Count = Count;
fn measure<S: Stream<Item=Option<String>>>(name: &str, stream: S) {
    let mut stream=pin!(stream);
    let mut cx=Context::from_waker(futures_util::task::noop_waker_ref());
    let (mut count,mut capacity_sum,mut last_capacity)=(0,0,0);
    ALLOCS.store(0,Ordering::Relaxed); REALLOCS.store(0,Ordering::Relaxed); REQUESTED.store(0,Ordering::Relaxed);
    ENABLED.store(true,Ordering::Relaxed);
    loop {
        match stream.as_mut().poll_next(&mut cx) {
            Poll::Ready(Some(Some(data))) => {count+=1;capacity_sum+=data.capacity();last_capacity=data.capacity(); std::hint::black_box(data);},
            Poll::Ready(Some(None)) => {},
            Poll::Ready(None) => break,
            Poll::Pending => panic!("ready source returned pending"),
        }
    }
    ENABLED.store(false,Ordering::Relaxed);
    println!("{name}: events={count}, allocs={}, reallocs={}, requested_bytes={}, output_capacity_sum={capacity_sum}, last_capacity={last_capacity}", ALLOCS.load(Ordering::Relaxed),REALLOCS.load(Ordering::Relaxed),REQUESTED.load(Ordering::Relaxed));
}
fn compare(label:&str, chunks:Vec<Bytes>) {
    println!("{label}");
    let input=||futures_util::stream::iter(chunks.iter().cloned().map(Ok::<_,std::convert::Infallible>));
    measure("baseline",v_baseline::SseByteStream::new(input()).map(|e|e.unwrap().data));
    measure("step1",v_step1::SseByteStream::new(input()).map(|e|e.unwrap().data));
    measure("step2",v_step2::SseByteStream::new(input()).map(|e|e.unwrap().data));
    measure("sse-core",sse_core::SseStream::new(input()).map(|e|match e.unwrap(){sse_core::SseEvent::Message(m)=>Some(m.data),_=>None}));
}
fn main() {
    compare("100000 small events", vec![Bytes::from(b"data: {\"t\":\"a\"}\n\n".repeat(100_000))]);
    let mut payload=format!("data: {}\ndata: tail\n\n","x".repeat(40000)).into_bytes();
    payload.extend_from_slice(&b"data: x\ndata: y\n\n".repeat(1000));
    let b=Bytes::from(payload);
    let chunks=(0..b.len()).step_by(1460).map(|i|b.slice(i..b.len().min(i+1460))).collect();
    compare("one 40k then 1000 multiline events, TCP chunks", chunks);
}
