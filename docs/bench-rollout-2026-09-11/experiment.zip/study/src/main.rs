use std::{hint::black_box, time::Instant, io::Write};
use bytes::Bytes;
use futures_util::StreamExt;
mod scenarios;
use scenarios::{DecodeCase, EncodeCase};
type DecodeRunner = fn(&DecodeCase, &tokio::runtime::Runtime, bool);
type EncodeRunner = fn(&EncodeCase);
macro_rules! runner {
    ($name:ident, $lib:ident, $stream:ident) => {
        #[inline(never)]
        fn $name(d:&DecodeCase, rt:&tokio::runtime::Runtime, borrowed:bool) {
            rt.block_on(async {
                let mut n=0;
                if borrowed {
                    let input=futures_util::stream::iter(d.chunks.iter().map(|b|Ok::<_,std::io::Error>(b.as_ref())));
                    let mut stream=$lib::$stream::new(input);
                    while let Some(e)=stream.next().await {black_box(e.unwrap());n+=1;}
                } else {
                    let input=tokio_stream::iter(d.chunks.iter().cloned().map(Ok::<_,std::io::Error>));
                    let mut stream=$lib::$stream::new(input);
                    while let Some(e)=stream.next().await {black_box(e.unwrap());n+=1;}
                }
                assert_eq!(n,d.events);
            });
        }
    }
}
runner!(original,v_original,SseByteStream);
runner!(baseline,v_baseline,SseByteStream);
runner!(step1,v_step1,SseByteStream);
runner!(step2,v_step2,SseByteStream);
runner!(core,sse_core,SseStream);
runner!(data_only,v_data_only,SseByteStream);
runner!(cold_copy,v_cold_copy,SseByteStream);
macro_rules! encoder {
    ($name:ident,$lib:ident) => {
        #[inline(never)]
        fn $name(d:&EncodeCase) {
            // Includes constructing an owned event; Criterion isolates encoding separately.
            black_box(Bytes::from($lib::Sse {event:d.event.clone(),data:Some(d.data.clone()),id:d.id.clone(),retry:d.retry}));
        }
    }
}
encoder!(encode_original,v_original);
encoder!(encode_baseline,v_baseline);
encoder!(encode_step1,v_step1);
encoder!(encode_step2,v_step2);

fn measure(mut run:impl FnMut(usize), names:&[&str], mode:&str, scenario:&str, count:usize, out:&mut std::fs::File) {
    let rounds:usize=std::env::var("STUDY_ROUNDS").unwrap_or("31".into()).parse().unwrap();
    let mut iterations=Vec::new();
    for i in 0..names.len() {
        run(i);let t=Instant::now();run(i);
        let n=(3_000_000/t.elapsed().as_nanos().max(1)).clamp(1,100000) as usize;
        for _ in 0..n {run(i);}iterations.push(n);
    }
    let mut rng=12345678u64;
    for round in 0..rounds {
        let mut order:Vec<_>=(0..names.len()).collect();
        for i in (1..order.len()).rev(){rng=rng.wrapping_mul(6364136223846793005).wrapping_add(1);order.swap(i,(rng>>32) as usize%(i+1));}
        for i in order {
            let n=iterations[i];let t=Instant::now();for _ in 0..n {run(i);}
            let ns=t.elapsed().as_nanos();
            writeln!(out,"{mode},{scenario},{},{round},{n},{ns},{},{count}",names[i],ns as f64/n as f64).unwrap();
        }
    }
}
fn main() {
    let output=std::env::var("STUDY_OUTPUT").unwrap_or("results.csv".into());
    let filter=std::env::var("STUDY_CASES").unwrap_or_default();
    let variants=std::env::var("STUDY_VARIANTS").unwrap_or_default();
    let borrowed=std::env::var("STUDY_MODE").as_deref()==Ok("borrowed");
    let include=|name:&str|variants.is_empty()||variants.split(',').any(|x|x==name);
    let select=|name:&str|filter.is_empty()||filter.split(',').any(|x|x==name);
    let mut out=std::fs::File::create(output).unwrap();
    writeln!(out,"mode,scenario,variant,round,iterations,total_ns,ns_per_iteration,events").unwrap();
    let rt=tokio::runtime::Builder::new_current_thread().build().unwrap();
    let runners:Vec<(&str,DecodeRunner)>=vec![("original",original as DecodeRunner),("baseline",baseline),("step1",step1),("step2",step2),("core",core),("data_only",data_only),("cold_copy",cold_copy)].into_iter().filter(|(n,_)|include(n)).collect();
    let names:Vec<_>=runners.iter().map(|(n,_)|*n).collect();
    for case in scenarios::decode_cases() {
        if !select(&case.name){continue;}
        measure(|i|runners[i].1(black_box(&case),&rt,borrowed),&names,if borrowed{"borrowed_ready"}else{"bytes_tokio"},&case.name,case.events,&mut out);
        println!("finished {}",case.name);
    }
    if !borrowed {
        let runners:Vec<(&str,EncodeRunner)>=vec![("original",encode_original as EncodeRunner),("baseline",encode_baseline),("step1",encode_step1),("step2",encode_step2)].into_iter().filter(|(n,_)|include(n)).collect();
        let names:Vec<_>=runners.iter().map(|(n,_)|*n).collect();
        for case in scenarios::encode_cases() {
            if !select(case.name){continue;}
            measure(|i|runners[i].1(black_box(&case)),&names,"encode_owned",case.name,1,&mut out);
            println!("finished encode/{}",case.name);
        }
    }
}
