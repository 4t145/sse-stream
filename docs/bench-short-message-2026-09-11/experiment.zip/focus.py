from pathlib import Path
import os,subprocess,time,json
p=Path(__file__).resolve().parent;os.chdir(p)
binary=next(f for f in (p/"target/release/deps").glob("compare-*") if f.is_file() and os.access(f,os.X_OK))
meta=[]
for i,order in enumerate(["current,baseline","baseline,current"],1):
 env=os.environ.copy();env["STUDY_ORDER"]=order;env["STUDY_CASES"]="large_utf8_tcp,large_json_utf8_tcp,large_json_base64_tcp,large_data_tcp_chunks,json_line_tcp";env["CRITERION_HOME"]=str(p/f"criterion/focus{i}")
 t=time.time()
 with (p/f"focus{i}.log").open("w") as log:
  subprocess.run(["taskset","-c","2",str(binary),"--bench","--noplot","--sample-size","80","--warm-up-time","0.2","--measurement-time","2"],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 meta.append({"round":i,"order":order,"elapsed_seconds":time.time()-t});(p/"focus-runs.json").write_text(json.dumps(meta,indent=2)+"\n")
 print(f"Focus {i} done",flush=True)
