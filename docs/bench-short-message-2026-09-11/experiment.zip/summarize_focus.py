from pathlib import Path
import csv,json,statistics
p=Path(__file__).resolve().parent
rows=[]
for case in ["large_utf8_tcp","large_json_utf8_tcp","large_json_base64_tcp","large_data_tcp_chunks","json_line_tcp"]:
 row={"case":case}
 for group in ["round1","round2","round3","focus1","focus2"]:
  a,b=[json.loads((p/"criterion"/group/case/v/"new/estimates.json").read_text())["mean"]["point_estimate"] for v in ["baseline","current"]]
  row[group]=(b/a-1)*100
 row["median_all_five_pct"]=statistics.median(row[k] for k in ["round1","round2","round3","focus1","focus2"])
 rows.append(row)
with (p/"focus-summary.csv").open("w") as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
