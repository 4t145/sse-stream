解码耗时单位：毫秒 / 完整 fixture，越小越快。倍数 = 对手耗时 ÷ 当前耗时，大于 1 表示当前更快。

| 场景 | 当前 ms | 优化前 ms | sse-core ms | 当前/优化前速度 | 当前/core速度 |
|---|---:|---:|---:|---:|---:|
| `small_data_whole_stream_chunk` | 3.477 | 4.135 | 3.556 | 1.19× | 1.05× |
| `small_data_tcp_chunks` | 3.523 | 4.081 | 3.499 | 1.12× | 0.99× |
| `small_data_event_chunks` | 4.009 | 4.683 | 4.666 | 1.15× | 1.17× |
| `small_data_4b_chunks` | 10.735 | 10.616 | 8.922 | 0.99× | 0.83× |
| `metadata_events_tcp_chunks` | 3.822 | 4.436 | 4.494 | 1.16× | 1.18× |
| `multiline_data_tcp_chunks` | 2.415 | 3.131 | 2.933 | 1.21× | 1.19× |
| `keepalive_whole_stream_chunk` | 1.022 | 1.060 | 1.175 | 1.04× | 1.15× |
| `keepalive_tcp_chunks` | 0.921 | 1.017 | 1.115 | 1.13× | 1.24× |
| `keepalive_line_chunks` | 3.308 | 3.405 | 3.177 | 1.03× | 0.96× |
| `keepalive_4b_chunks` | 10.342 | 10.261 | 9.637 | 0.99× | 0.88× |
| `large_data_event_chunks` | 0.077 | 0.078 | 0.095 | 1.00× | 1.24× |
| `large_data_tcp_chunks` | 0.118 | 0.121 | 0.139 | 1.01× | 1.14× |
| `medium_data_10b_chunks` | 1.926 | 1.954 | 1.924 | 1.02× | 1.00× |
| `json_line_tcp` | 0.938 | 1.144 | 0.956 | 1.20× | 0.99× |
| `json_metadata_after_tcp` | 1.457 | 1.699 | 1.688 | 1.17× | 1.22× |
| `json_crlf_tcp` | 2.268 | 2.201 | 2.299 | 1.02× | 1.08× |
| `large_utf8_tcp` | 0.244 | 0.223 | 1.025 | 0.91× | 4.12× |
| `large_utf8_event` | 0.191 | 0.191 | 0.968 | 1.00× | 5.08× |
| `large_json_utf8_tcp` | 0.241 | 0.234 | 1.146 | 0.93× | 4.76× |
| `large_json_escaped_tcp` | 0.131 | 0.134 | 0.145 | 1.03× | 1.12× |
| `large_json_base64_tcp` | 0.137 | 0.129 | 0.139 | 0.95× | 1.01× |
| `mixed_json_tcp` | 0.506 | 0.590 | 0.811 | 1.17× | 1.57× |
| `mixed_json_whole` | 0.468 | 0.517 | 0.697 | 1.12× | 1.48× |
| `mixed_multiline_tcp` | 0.434 | 0.479 | 0.727 | 1.08× | 1.65× |
| `mixed_multiline_whole` | 0.416 | 0.481 | 0.732 | 1.12× | 1.79× |
| `alternating_sizes_tcp` | 0.129 | 0.128 | 0.144 | 1.02× | 1.10× |
| `varied_sizes_tcp` | 0.035 | 0.034 | 0.038 | 1.01× | 1.03× |
| `comment_crlf_tcp` | 0.391 | 0.455 | 1.216 | 1.16× | 3.06× |

编码耗时单位：纳秒 / 单个事件，输入 Sse 克隆不计时。sse-core 无编码 API。

| 场景 | 当前 ns | 优化前 ns | sse-core | 当前/优化前速度 |
|---|---:|---:|---:|---:|
| `small_json` | 14.1 | 14.9 | N/A | 1.05× |
| `metadata_json` | 80.0 | 80.5 | N/A | 1.00× |
| `large_ascii` | 711.5 | 694.5 | N/A | 1.03× |
| `large_utf8` | 719.0 | 723.3 | N/A | 1.01× |
| `empty_with_retry` | 46.0 | 46.8 | N/A | 1.02× |
