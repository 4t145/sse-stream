use bytes::Bytes;
use futures_util::StreamExt;
use std::convert::Infallible;
async fn check(data: &[u8], cuts: &[usize]) {
    let input = Bytes::copy_from_slice(data);
    let mut start = 0;
    let mut chunks = Vec::new();
    for &end in cuts { chunks.push(Ok::<_, Infallible>(input.slice(start..end))); start = end; }
    chunks.push(Ok(input.slice(start..)));
    let old: Vec<_> = v_baseline::SseByteStream::new(futures_util::stream::iter(chunks.clone())).map(|event| format!("{event:?}")).collect().await;
    let new: Vec<_> = v_boundary::SseByteStream::new(futures_util::stream::iter(chunks.clone())).map(|event| format!("{event:?}")).collect().await;
    assert_eq!(old, new, "data={data:?}, cuts={cuts:?}");
    let new: Vec<_> = current::SseByteStream::new(futures_util::stream::iter(chunks.clone())).map(|event| format!("{event:?}")).collect().await;
    assert_eq!(old, new, "data={data:?}, cuts={cuts:?}");
}
#[tokio::test]
async fn prototype_preserves_baseline_across_partitions() {
    let cases: &[&[u8]] = &[
        b"data: hello\n\ndata: second\n\n",
        b"data:\n\ndata:\ndata:\n\n",
        b"data:  two spaces\n\n",
        b"id: 12\nevent: update\ndata: first\ndata: second\n\n",
        b"data: hello\r\n\r\ndata: second\r\r",
        b":comment\n\ndata:x\r\n\n:comment\r\rdata:y\n\n",
        b"\xef\xbb\xbfdata: first\n\ndata: second\n\n",
        "data: 你好🦀\n\ndata: 世界🌍\n\n".as_bytes(),
        b"data: valid\n\ndata: \xff\n\ndata: after\n\n",
        b"data: prefix\ndata: \xff\n\ndata: after\n\n",
        b"data: done\n\nunknown:value\n\ndata: after\n\n",
        b"event:a\nevent:b\ndata: x\n\n",
        b"id:\0\ndata: x\n\nretry: 1000\ndata: y\n\n",
        b"\ndata: completed\n\ndata: unfinished",
        b"event: alone\n\ndata: after\n\n",
    ];
    for &case in cases {
        check(case, &[]).await;
        for i in 0..=case.len() { check(case, &[i]).await; }
        for width in 1..=64 {
            let cuts: Vec<_> = (width..case.len()).step_by(width).collect();
            check(case, &cuts).await;
        }
    }
    let mut input = Vec::new();
    for i in 0..200 {
        input.extend_from_slice(format!("data: {}\n\n", "ab你".repeat(i % 47)).as_bytes());
    }
    for seed in 1u64..=100 {
        let mut state = seed;
        let mut cuts = Vec::new();
        let mut pos = 0;
        loop {
            state = state.wrapping_mul(6364136223846793005).wrapping_add(1);
            pos += 1 + (state >> 32) as usize % 127;
            if pos >= input.len() { break; }
            cuts.push(pos);
        }
        check(&input, &cuts).await;
    }
    for offset in [0, 63, 64, 127, 128, 255, 256, 511, 512, 4095] {
        let mut data = b"data: ".to_vec();
        let mut value = b"word".repeat(2048);
        value[offset] = 0xff;
        data.extend_from_slice(&value);
        data.extend_from_slice(b"\n\ndata: after\n\n");
        check(&data, &[]).await;
        for width in [1, 4, 7, 63, 64, 255, 1024] {
            let cuts: Vec<_> = (width..data.len()).step_by(width).collect();
            check(&data, &cuts).await;
        }
    }

    for text in ["你".repeat(2000), "{\"content\":\"你好，世界\"}".repeat(200)] {
        let data = format!("data: {text}\n\ndata: after\n\n").into_bytes();
        check(&data, &[]).await;
        for width in [1, 2, 3, 7, 63, 64, 127, 255, 256, 1024, 1460] {
            let cuts: Vec<_> = (width..data.len()).step_by(width).collect();
            check(&data, &cuts).await;
        }
    }

}
