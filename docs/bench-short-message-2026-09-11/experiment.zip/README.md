2026-09-11: short-message completion and data scanning optimization

The baseline is the worktree immediately before this optimization, including the already implemented SIMD UTF-8 and adaptive capacity changes. It is not the crates.io package. current/ is the final implemented source snapshot, and sse-core is pinned to 0.2.3. All performance comparisons use default features and identical existing fixtures from benches/scenarios/mod.rs (copied to src/scenarios.rs).

Run from this directory after unzipping:

    cargo fetch --locked
    cargo test --offline --release --test equivalence
    cargo run --offline --release --example preflight
    python3 run_criterion.py
    python3 summarize_criterion.py

The supplied preflight-final.csv records the completed correctness check before timing. CPU 2 is used by run_criterion.py; adjust for a different machine. The script builds the release benchmark and runs 28 decoder cases plus 5 encoder cases, with three implementation orders. No encoder changes were made. Input Bytes clones, the original StrError input type, Tokio stream behavior, and output consumption are preserved. Encoding excludes cloning the input Sse (Criterion iter_batched/LargeInput), as in the repository bench.

Criterion settings: 40 samples, 150 ms warm-up, 700 ms target measurement, 10,000 bootstrap resamples; slow cases may exceed the target. The three rounds rotate baseline/current/core. Absolute times are medians of three round mean point estimates; ratios are medians of within-round competitor/current ratios, so dividing displayed median times can give a slightly different number. summary.csv includes min/max of the three ratios and a descriptive 3% consistency classification, not a significance test. rounds.csv includes every mean, median, and Criterion mean bootstrap CI. Raw sample.json/estimates.json are under criterion/.

Screening preceded the final changes: 31 rounds, deterministic shuffled variant order, approximately 3 ms measurement blocks, ratios paired against the same-round baseline. Decode inputs and consumption match the original fixture harness, while the runtime driver is rt.block_on rather than Criterion. Do not mix screening absolute times with Criterion times. The screening source includes every candidate, so the final build's code layout differs from early screening builds. CSVs preserve the actual historical observations; no exact bit-for-bit binary reproduction is claimed.

Candidate labels:
- baseline: untouched pre-change source.
- boundary: dispatch a data line followed by LF LF immediately, retaining the original validation and allocation policy.
- scan: scalar only for slices up to 16 bytes, otherwise memchr2 from the beginning; no boundary shortcut.
- combined: boundary + scan.
- head4/head8: boundary + shorter scalar prefix for every line.
- guarded: boundary + raw memchr2 for long non-comment input slices.
- field_scan: boundary + recognize data prefix once, scan its value separately; generic scanner remains unchanged.
- early_comment: field_scan + process comments before data recognition.
- current: selected early_comment candidate with duplicate checks in the incomplete-line branch removed, formatted, and regression tested.

CSV groups: screen.csv (baseline/boundary/scan/combined/core), heads.csv, guarded.csv, field.csv, comment.csv. *-summary.csv gives paired median and p10/p90 ratio changes. Re-run screening with STUDY_VARIANTS, STUDY_OUTPUT, STUDY_CASES, STUDY_ROUNDS after building the binary, e.g.:

    cargo build --offline --release
    STUDY_VARIANTS=baseline,boundary,early_comment,core STUDY_OUTPUT=rerun.csv taskset -c 2 target/release/sse-short-path-study
    python3 summarize_screen.py rerun.csv

Semantic verification includes independently expected benchmark events, all single split points, widths 1..64, 100 randomized layouts, BOM/CRLF/metadata/multiline/empty fields, invalid UTF-8 and subsequent events. Root test outputs and copies of the two added/extended regression test files are included. The debug tracing test is isolated in its own integration-test binary to avoid interference with concurrent tests that have no subscriber.

No custom RUSTFLAGS or LTO; i5-13600K logical CPU 2, powersave governor, frequency not locked. Benchmarks are sequential with no concurrent compiler/tests. They measure in-memory stream parsing and encoding, not TCP latency, JSON decoding, application queues, or RSS. JSON is SSE-framed payload, not raw NDJSON.

Follow-up validation of the final implementation:

    cargo build --offline --release --bin sse-short-path-study
    STUDY_VARIANTS=baseline,current,core STUDY_ROUNDS=51 STUDY_OUTPUT=final-screen.csv taskset -c 2 target/release/sse-short-path-study
    python3 summarize_screen.py final-screen.csv
    python3 focus.py
    python3 summarize_focus.py

focus.py reuses the exact Criterion binary from the full run. It tests large_utf8_tcp, large_json_utf8_tcp, large_json_base64_tcp, large_data_tcp_chunks, and json_line_tcp twice in opposite baseline/current order, with 80 samples and 2 s measurement. focus-summary.csv keeps the three original full-run ratios and both follow-ups before taking a median of all five. No original slow observations were deleted. The final diagnostic includes a differently compiled rt.block_on wrapper: relative-to-baseline improvements agree with Criterion, but cross-library ranking for short JSON does not, so no stable parity claim is made.
