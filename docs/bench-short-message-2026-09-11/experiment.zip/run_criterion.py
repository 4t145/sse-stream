from pathlib import Path
import subprocess,os,json,time
root=Path(__file__).resolve().parent
os.chdir(root)
subprocess.run(["cargo","build","--offline","--release","--bench","compare"],check=True)
binary=next(p for p in (root/"target/release/deps").glob("compare-*") if p.is_file() and os.access(p,os.X_OK))
runs=[]
for i,order in enumerate(["baseline,current,core","current,core,baseline","core,baseline,current"],1):
 env=os.environ.copy();env["STUDY_ORDER"]=order;env["CRITERION_HOME"]=str(root/f"criterion/round{i}")
 start=time.time();print(f"Round {i}: {order}",flush=True)
 with (root/f"criterion-round{i}.log").open("w") as log:
  subprocess.run(["taskset","-c","2",str(binary),"--bench","--noplot"],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 runs.append({"round":i,"order":order,"start_unix":start,"elapsed_seconds":time.time()-start})
 (root/"criterion-runs.json").write_text(json.dumps(runs,indent=2)+"\n")
 print(f"Round {i} completed",flush=True)
