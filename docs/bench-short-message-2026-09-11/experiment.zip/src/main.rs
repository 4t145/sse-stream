use bytes::Bytes;
use tokio_stream::StreamExt;
use std::{hint::black_box, time::Instant, io::Write};
mod scenarios;
#[derive(Debug, Clone, thiserror::Error)]
#[error("{0}")]
struct StrError(String);
struct Case { name: String, chunks: Vec<Result<Bytes, StrError>>, events: usize }
type Runner = fn(&Case, &tokio::runtime::Runtime);
macro_rules! runner {
 ($name:ident, $lib:ident, $stream:ident) => {
  #[inline(never)]
  fn $name(case: &Case, rt: &tokio::runtime::Runtime) {
   rt.block_on(async {
    let mut stream=$lib::$stream::new(tokio_stream::iter(case.chunks.iter().cloned()));
    let mut n=0;
    while let Some(event)=stream.next().await {black_box(event.expect("parse error"));n+=1;}
    assert_eq!(n,case.events);
   });
  }
 }
}
runner!(baseline,v_baseline,SseByteStream);
runner!(boundary,v_boundary,SseByteStream);
runner!(scan,v_scan,SseByteStream);
runner!(combined,v_combined,SseByteStream);
runner!(head4,v_head4,SseByteStream);
runner!(head8,v_head8,SseByteStream);
runner!(guarded,v_guarded,SseByteStream);
runner!(field_scan,v_field_scan,SseByteStream);
runner!(early_comment,v_early_comment,SseByteStream);
runner!(implemented,current,SseByteStream);
runner!(core,sse_core,SseStream);
fn main() {
 let rt=tokio::runtime::Builder::new_current_thread().build().expect("runtime");
 let variants=std::env::var("STUDY_VARIANTS").unwrap_or_default();
 let filter=std::env::var("STUDY_CASES").unwrap_or_default();
 let output=std::env::var("STUDY_OUTPUT").unwrap_or("screen.csv".into());
 let rounds:usize=std::env::var("STUDY_ROUNDS").unwrap_or("31".into()).parse().expect("rounds");
 let mut out=std::fs::File::create(output).expect("output");
 writeln!(out,"case,variant,round,iterations,total_ns,ns_per_iteration").expect("header");
 let runners:Vec<(&str,Runner)>=vec![
 ("baseline",baseline as Runner),
 ("boundary",boundary as Runner),
 ("scan",scan as Runner),
 ("combined",combined as Runner),
 ("head4",head4 as Runner),
 ("head8",head8 as Runner),
 ("guarded",guarded as Runner),
 ("field_scan",field_scan as Runner),
 ("early_comment",early_comment as Runner),
 ("current",implemented as Runner),
 ("core",core as Runner),
 ].into_iter().filter(|(n,_)|variants.is_empty()||variants.split(',').any(|v|v==*n)).collect();
 for fixture in scenarios::decode_cases() {
  if !filter.is_empty()&&!filter.split(',').any(|n|n==fixture.name) {continue;}
  let case=Case{name:fixture.name,chunks:fixture.chunks.into_iter().map(Ok).collect(),events:fixture.events};
  let mut iterations=Vec::new();
  for (_,run) in &runners {
   run(&case,&rt);let start=Instant::now();run(&case,&rt);
   let n=(3_000_000/start.elapsed().as_nanos().max(1)).clamp(1,100000) as usize;
   for _ in 0..n {run(&case,&rt);}iterations.push(n);
  }
  let mut rng=12345678u64;
  for round in 0..rounds {
   let mut order:Vec<_>=(0..runners.len()).collect();
   for i in (1..order.len()).rev() {rng=rng.wrapping_mul(6364136223846793005).wrapping_add(1);order.swap(i,(rng>>32) as usize%(i+1));}
   for i in order {
    let n=iterations[i];let start=Instant::now();for _ in 0..n {runners[i].1(black_box(&case),&rt);}
    let ns=start.elapsed().as_nanos();
    writeln!(out,"{},{},{round},{n},{ns},{}",case.name,runners[i].0,ns as f64/n as f64).expect("row");
   }
  }
  println!("finished {}",case.name);
 }
}
