from pathlib import Path
import csv, statistics, sys

root=Path(__file__).resolve().parent
path=Path(sys.argv[1]) if len(sys.argv)>1 else root/'screen.csv'
data=list(csv.DictReader(path.open()))
lookup={(r['case'],r['variant'],r['round']):float(r['ns_per_iteration']) for r in data}
cases=list(dict.fromkeys(r['case'] for r in data))
variants=[v for v in dict.fromkeys(r['variant'] for r in data) if v!='baseline']
out=[]
for case in cases:
    for variant in variants:
        ratios=[t/lookup[(name,'baseline',rnd)] for (name,v,rnd),t in lookup.items() if name==case and v==variant and (name,'baseline',rnd) in lookup]
        if not ratios: continue
        ratios.sort()
        out.append({'case':case,'variant':variant,'rounds':len(ratios),'time_change_pct':(statistics.median(ratios)-1)*100,'p10_pct':(ratios[len(ratios)//10]-1)*100,'p90_pct':(ratios[len(ratios)*9//10]-1)*100})
with path.with_name(path.stem+'-summary.csv').open('w') as f:
    writer=csv.DictWriter(f,fieldnames=list(out[0]));writer.writeheader();writer.writerows(out)
for case in cases:
    print(case, ' '.join(f"{r['variant']} {r['time_change_pct']:+.1f}%" for r in out if r['case']==case))
