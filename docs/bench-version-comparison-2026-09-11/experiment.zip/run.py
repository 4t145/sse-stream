#!/usr/bin/env python3
"""Run all current benchmark fixtures with three orders on one logical CPU."""
from pathlib import Path
import json, os, shutil, subprocess, time

root = Path(__file__).resolve().parent
os.chdir(root)
subprocess.run(["cargo", "build", "--offline", "--release", "--benches"], check=True)
with (root / "preflight.csv").open("w") as log:
    subprocess.run(["target/release/sse-published-comparison"], stdout=log, check=True)
print("Preflight passed: 28 decode fixtures, 5 encode fixtures", flush=True)
binary = next(p for p in (root / "target/release/deps").glob("compare-*") if p.is_file() and os.access(p,os.X_OK))
orders = ["current,published,core", "published,core,current", "core,current,published"]
run_metadata = []
for i, order in enumerate(orders, 1):
    env = os.environ.copy()
    env["STUDY_ORDER"] = order
    env["CRITERION_HOME"] = str(root / f"results/round{i}")
    started = time.time()
    print(f"Round {i}: {order}", flush=True)
    with (root / f"round{i}.log").open("w") as log:
        subprocess.run(["taskset", "-c", "2", str(binary), "--bench", "--noplot"], env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    run_metadata.append({"round":i,"order":order,"started_unix":started,"elapsed_seconds":time.time()-started})
    (root / "runs.json").write_text(json.dumps(run_metadata, indent=2)+"\n")
    print(f"Round {i} completed in {time.time()-started:.1f}s", flush=True)
