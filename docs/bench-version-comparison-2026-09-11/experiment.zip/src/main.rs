use bytes::Bytes;
use tokio_stream::StreamExt;
mod scenarios;

#[derive(Debug, Clone, thiserror::Error)]
#[error("{0}")]
struct StrError(String);

#[derive(Debug, Default, PartialEq, Eq)]
struct Event { event: Option<String>, data: Option<String>, id: Option<String>, retry: Option<u64> }

// Reference for exactly these LF/CRLF fixtures, independent of all three decoders.
fn reference(chunks: &[Bytes]) -> Vec<Event> {
    let wire: Vec<u8> = chunks.iter().flat_map(|b| b.iter().copied()).collect();
    let text = std::str::from_utf8(&wire).unwrap();
    let mut out = Vec::new();
    let mut event = Event::default();
    for line in text.lines() {
        if line.is_empty() {
            if event.data.is_some() { out.push(std::mem::take(&mut event)); }
            continue;
        }
        let (field, value) = line.split_once(':').unwrap();
        let value = value.strip_prefix(' ').unwrap_or(value);
        match field {
            "data" => match &mut event.data {
                Some(s) => { s.push('\n'); s.push_str(value); },
                None => event.data = Some(value.to_owned()),
            },
            "event" => event.event = (value != "message").then(||value.to_owned()),
            "id" => event.id = Some(value.to_owned()),
            "" => {},
            _ => panic!("unexpected field in fixture"),
        }
    }
    out
}

#[tokio::main(flavor="current_thread")]
async fn main() {
    println!("kind,case,bytes,chunks,events,validation");
    for case in scenarios::decode_cases() {
        let expected = reference(&case.chunks);
        assert_eq!(expected.len(), case.events, "{} reference count",case.name);
        let total = case.chunks.iter().map(Bytes::len).sum::<usize>();
        let chunk_count = case.chunks.len();
        let chunks: Vec<Result<_,StrError>> = case.chunks.into_iter().map(Ok).collect();
        macro_rules! check {
            ($lib:ident, $stream:ident, $constructor:ident) => {{
                let mut stream = $lib::$stream::$constructor(tokio_stream::iter(chunks.iter().cloned()));
                let mut n = 0;
                while let Some(value) = stream.next().await {
                    let value = value.unwrap();
                    let event = Event { event:value.event.filter(|e|e!="message"),data:value.data,id:value.id,retry:value.retry };
                    assert_eq!(event,expected[n],"{} {} event {}",case.name,stringify!($lib),n);
                    n += 1;
                }
                assert_eq!(n,case.events);
            }}
        }
        check!(current,SseByteStream,new);
        check!(published,SseStream,from_bytes_stream);
        let mut stream = sse_core::SseStream::new(tokio_stream::iter(chunks.iter().cloned()));
        let mut n = 0;
        while let Some(value) = stream.next().await {
            let sse_core::SseEvent::Message(value) = value.unwrap() else { panic!("unexpected retry"); };
            let event = Event { event:(value.event!="message").then(||value.event.into_owned()),data:Some(value.data),id:value.last_event_id.map(|s|s.to_string()),retry:None };
            assert_eq!(event,expected[n],"{} core event {}",case.name,n);
            n += 1;
        }
        assert_eq!(n,case.events);
        println!("decode,{},{total},{chunk_count},{},all_three_match_reference",case.name,case.events);
    }
    for case in scenarios::encode_cases() {
        macro_rules! event { ($lib:ident) => { $lib::Sse {event:case.event.clone(),data:Some(case.data.clone()),id:case.id.clone(),retry:case.retry} }; }
        let a = Bytes::from(event!(current));
        let b = Bytes::from(event!(published));
        assert_eq!(a,b,"{} encoding wire differs",case.name);
        println!("encode,{},{},1,1,identical_wire",case.name,a.len());
    }
}
