2026-09-11: current worktree vs crates.io sse-stream 0.2.6 vs sse-core 0.2.3

This standalone project snapshots the worktree library and uses an exact registry dependency for the published package. Cargo.lock distinguishes the two packages even though both say 0.2.6. All three use their default features. The downloaded crate checksums were checked against the freshly updated crates.io sparse index; manifest.json records the values and source hashes.

src/scenarios.rs is an unchanged copy of the repository's benches/scenarios/mod.rs. source-bench.rs records the original harness. benches/compare.rs preserves its timed work and StrError input, adds the registry version, and makes variant order configurable. Published 0.2.6 exposes SseStream::from_bytes_stream, while the worktree benchmark uses SseByteStream::new. sse-core has no SSE encoder API.

To reproduce after unzipping:

    cargo fetch --locked
    python3 run.py
    python3 summarize.py

Edit CPU 2 in run.py if that logical CPU is not available. run.py does a release build, validates all outputs outside timing, then runs all scenarios three times with rotated implementation order. It writes results/round{1,2,3}/ and complete logs. Existing dependencies allow the build itself to run offline. run.py replaces prior round output on another invocation.

Criterion settings: 40 samples, 200 ms warm-up, 1 s target measurement, 10,000 bootstrap resamples; slow cases can exceed the target duration. This is a comparison run, shorter per round than the repository default of 100 samples and 10 seconds. No custom RUSTFLAGS or LTO. One current-thread Tokio runtime per decode case. Only one benchmark runs at a time, pinned to CPU 2, with no concurrent compilation. CPU frequency was not locked (powersave governor), so small differences should not be treated as statistically decisive.

Preflight independently constructs the expected messages from the fixtures, checks every event and count against all three decoders, and checks byte-identical output for both encoders. Absent event names and explicit "message" names are normalized to the same default event name. Existing decode fixtures intentionally omit retry because sse-core emits it separately. The five encoder fixtures include retry and u64::MAX.

Decode includes cloning input Bytes and consuming/dropping every output event, with no network I/O, application queue, or JSON deserialization. JSON-line cases contain SSE-framed JSON in data fields, not raw NDJSON input. Encode measures owned Sse -> Bytes, using Criterion iter_batched/LargeInput to exclude input cloning as in the existing benchmark.

summary.csv uses the median of three per-round Criterion mean point estimates for each implementation's absolute time. Speedup is the median of the three round-matched competitor/current ratios; it can differ slightly from the ratio of displayed median times. Ratios above 1 favor the current version. The _min/_max columns show the three-round spread, not confidence intervals. rounds.csv contains every mean, sample median, and Criterion 95% bootstrap CI. Raw sample.json and estimates.json files preserve the underlying measurements.

A +/-3% time-change band is only a descriptive near-tie band, not a significance test. Neither scenario counts nor an unweighted aggregate imply actual application workload performance. This run does not measure RSS, time to first event, or real-network latency.
