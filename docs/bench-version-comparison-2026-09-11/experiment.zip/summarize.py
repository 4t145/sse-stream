#!/usr/bin/env python3
from pathlib import Path
import csv, json, statistics

root = Path(__file__).resolve().parent
fixtures = list(csv.DictReader((root/'preflight.csv').open()))
rows = []
raw = []
for fixture in fixtures:
    case = fixture['case'] if fixture['kind']=='decode' else 'encode_'+fixture['case']
    variants = ['current','published','core'] if fixture['kind']=='decode' else ['current','published']
    means = {v:[] for v in variants}
    for round_no in range(1,4):
        for variant in variants:
            p = root/f'results/round{round_no}'/case/variant/'new/estimates.json'
            if not p.exists(): continue
            stats = json.loads(p.read_text())
            mean = stats['mean']['point_estimate']
            means[variant].append(mean)
            raw.append({'kind':fixture['kind'],'case':fixture['case'],'round':round_no,'variant':variant,'mean_ns':mean,'median_ns':stats['median']['point_estimate'],'mean_ci95_low_ns':stats['mean']['confidence_interval']['lower_bound'],'mean_ci95_high_ns':stats['mean']['confidence_interval']['upper_bound']})
    if not all(len(means[v])==3 for v in variants): continue
    row = dict(fixture)
    for variant in variants:
        row[variant+'_ns'] = statistics.median(means[variant])
        row[variant+'_ns_min'] = min(means[variant])
        row[variant+'_ns_max'] = max(means[variant])
        row[variant+'_mib_s'] = int(fixture['bytes'])/row[variant+'_ns']*1e9/2**20
    for competitor in ['published','core']:
        if competitor not in variants: continue
        ratios = [a/b for a,b in zip(means[competitor],means['current'])]
        row['speedup_vs_'+competitor] = statistics.median(ratios)
        row['speedup_vs_'+competitor+'_min'] = min(ratios)
        row['speedup_vs_'+competitor+'_max'] = max(ratios)
        row['time_change_vs_'+competitor+'_pct'] = statistics.median([(b/a-1)*100 for a,b in zip(means[competitor],means['current'])])
        deltas = [(1/r-1)*100 for r in ratios]
        row['consistency_vs_'+competitor] = (
            'all_rounds_faster_over_3pct' if max(deltas)<-3 else
            'all_rounds_slower_over_3pct' if min(deltas)>3 else
            'all_rounds_within_3pct' if all(abs(d)<=3 for d in deltas) else
            'mixed_or_near_boundary'
        )
    rows.append(row)

def write_csv(path, data):
    if not data: return
    columns = list(dict.fromkeys(k for r in data for k in r))
    with path.open('w') as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader(); writer.writerows(data)

write_csv(root/'summary.csv',rows)
write_csv(root/'rounds.csv',raw)
if not rows:
    print(f'{len(raw)} variant-round measurements available; waiting for all three rounds')
    raise SystemExit(0)

def delta(v):
    return f'{v:+.1f}%'

out = [
    '解码耗时单位：毫秒 / 完整 fixture，越小越快。倍数 = 对手耗时 ÷ 当前耗时，大于 1 表示当前更快。',
    '',
    '| 场景 | 当前 ms | 发布版 ms | sse-core ms | 当前/发布版速度 | 当前/core速度 |',
    '|---|---:|---:|---:|---:|---:|',
]
for r in rows:
    if r['kind']!='decode': continue
    out.append(f"| `{r['case']}` | {r['current_ns']/1e6:.3f} | {r['published_ns']/1e6:.3f} | {r['core_ns']/1e6:.3f} | {r['speedup_vs_published']:.2f}× | {r['speedup_vs_core']:.2f}× |")
out += [
    '',
    '编码耗时单位：纳秒 / 单个事件，输入 Sse 克隆不计时。sse-core 无编码 API。',
    '',
    '| 场景 | 当前 ns | 发布版 ns | sse-core | 当前/发布版速度 |',
    '|---|---:|---:|---:|---:|',
]
for r in rows:
    if r['kind']!='encode': continue
    out.append(f"| `{r['case']}` | {r['current_ns']:.1f} | {r['published_ns']:.1f} | N/A | {r['speedup_vs_published']:.2f}× |")
(root/'tables.md').write_text('\n'.join(out)+'\n')
for competitor in ['published','core']:
    data = [r for r in rows if r['kind']=='decode']
    if not data: continue
    print(competitor,'faster >3%:',sum(r['time_change_vs_'+competitor+'_pct'] < -3 for r in data),'within ±3%:',sum(abs(r['time_change_vs_'+competitor+'_pct']) <= 3 for r in data),'slower >3%:',sum(r['time_change_vs_'+competitor+'_pct'] > 3 for r in data))
    for r in data:
        if r['time_change_vs_'+competitor+'_pct']>3:
            print('  slower',r['case'],delta(r['time_change_vs_'+competitor+'_pct']))
print('\n'.join(out))
