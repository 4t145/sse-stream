use bytes::Bytes;
use criterion::{criterion_group, criterion_main, BatchSize, Criterion};
use std::{hint::black_box, time::Duration};
use tokio_stream::StreamExt;
#[path = "../src/scenarios.rs"]
mod scenarios;

#[derive(Debug, Clone, thiserror::Error)]
#[error("{0}")]
struct StrError(String);

fn compare(c: &mut Criterion) {
    let order = std::env::var("STUDY_ORDER").unwrap_or_else(|_| "current,published,core".into());
    let filter = std::env::var("STUDY_CASES").unwrap_or_default();
    for case in scenarios::decode_cases() {
        if !filter.is_empty() && !filter.split(',').any(|name| name == case.name) { continue; }
        let mut group = c.benchmark_group(&case.name);
        group.throughput(criterion::Throughput::Bytes(case.chunks.iter().map(Bytes::len).sum::<usize>() as u64));
        let chunks: Vec<Result<_, StrError>> = case.chunks.into_iter().map(Ok).collect();
        let rt = tokio::runtime::Builder::new_current_thread().build().unwrap();
        macro_rules! run {
            ($name:expr, $lib:ident, $stream:ident, $constructor:ident) => {{
                group.bench_function($name, |b| b.to_async(rt.handle()).iter(|| async {
                    let mut stream = $lib::$stream::$constructor(tokio_stream::iter(chunks.iter().cloned()));
                    let mut n = 0;
                    while let Some(event) = stream.next().await { black_box(event.expect("parse error")); n += 1; }
                    assert_eq!(n, case.events);
                }));
            }}
        }
        for name in order.split(',') {
            match name {
                "current" => run!("current", current, SseByteStream, new),
                "published" => run!("published", published, SseStream, from_bytes_stream),
                "core" => run!("core", sse_core, SseStream, new),
                _ => panic!("unknown variant"),
            }
        }
        group.finish();
    }
    for case in scenarios::encode_cases() {
        if !filter.is_empty() && !filter.split(',').any(|name| name == case.name) { continue; }
        let mut group = c.benchmark_group(format!("encode_{}",case.name));
        macro_rules! run {
            ($name:expr, $lib:ident) => {{
                let event = $lib::Sse {event:case.event.clone(),data:Some(case.data.clone()),id:case.id.clone(),retry:case.retry};
                group.throughput(criterion::Throughput::Bytes(Bytes::from(event.clone()).len() as u64));
                group.bench_function($name, |b| b.iter_batched(|| event.clone(), |event| black_box(Bytes::from(event)), BatchSize::LargeInput));
            }}
        }
        for name in order.split(',') {
            match name {
                "current" => run!("current", current),
                "published" => run!("published", published),
                "core" => {},
                _ => panic!("unknown variant"),
            }
        }
        group.finish();
    }
}
criterion_group! {
    name = benches;
    config = Criterion::default().sample_size(40).warm_up_time(Duration::from_millis(200)).measurement_time(Duration::from_millis(1000)).nresamples(10000);
    targets = compare,
}
criterion_main!(benches);
