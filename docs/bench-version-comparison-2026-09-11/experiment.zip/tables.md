解码耗时单位：毫秒 / 完整 fixture，越小越快。倍数 = 对手耗时 ÷ 当前耗时，大于 1 表示当前更快。

| 场景 | 当前 ms | 发布版 ms | sse-core ms | 当前/发布版速度 | 当前/core速度 |
|---|---:|---:|---:|---:|---:|
| `small_data_whole_stream_chunk` | 4.072 | 5.043 | 3.474 | 1.29× | 0.86× |
| `small_data_tcp_chunks` | 4.013 | 5.196 | 3.507 | 1.30× | 0.87× |
| `small_data_event_chunks` | 4.629 | 6.143 | 4.676 | 1.32× | 1.02× |
| `small_data_4b_chunks` | 11.062 | 16.000 | 9.955 | 1.46× | 0.90× |
| `metadata_events_tcp_chunks` | 4.788 | 8.080 | 5.162 | 1.77× | 1.08× |
| `multiline_data_tcp_chunks` | 2.973 | 4.674 | 3.142 | 1.55× | 1.10× |
| `keepalive_whole_stream_chunk` | 1.030 | 2.236 | 1.164 | 2.20× | 1.16× |
| `keepalive_tcp_chunks` | 1.051 | 2.126 | 1.228 | 2.02× | 1.16× |
| `keepalive_line_chunks` | 3.595 | 7.457 | 3.331 | 2.07× | 0.94× |
| `keepalive_4b_chunks` | 10.948 | 22.002 | 9.926 | 2.03× | 0.94× |
| `large_data_event_chunks` | 0.083 | 0.878 | 0.100 | 10.55× | 1.16× |
| `large_data_tcp_chunks` | 0.131 | 1.045 | 0.138 | 7.75× | 1.03× |
| `medium_data_10b_chunks` | 1.794 | 3.467 | 1.825 | 1.90× | 1.01× |
| `json_line_tcp` | 1.099 | 1.578 | 0.827 | 1.43× | 0.75× |
| `json_metadata_after_tcp` | 1.622 | 2.182 | 1.761 | 1.35× | 1.06× |
| `json_crlf_tcp` | 2.343 | 2.884 | 2.434 | 1.25× | 1.06× |
| `large_utf8_tcp` | 0.231 | 1.964 | 1.003 | 8.30× | 4.33× |
| `large_utf8_event` | 0.188 | 1.677 | 0.999 | 8.92× | 5.39× |
| `large_json_utf8_tcp` | 0.245 | 1.995 | 1.084 | 8.16× | 4.44× |
| `large_json_escaped_tcp` | 0.132 | 1.056 | 0.144 | 7.99× | 1.09× |
| `large_json_base64_tcp` | 0.127 | 1.002 | 0.135 | 7.79× | 1.04× |
| `mixed_json_tcp` | 0.589 | 0.989 | 0.740 | 1.68× | 1.27× |
| `mixed_json_whole` | 0.524 | 1.139 | 0.745 | 2.19× | 1.45× |
| `mixed_multiline_tcp` | 0.495 | 1.036 | 0.779 | 2.09× | 1.57× |
| `mixed_multiline_whole` | 0.479 | 0.966 | 0.823 | 2.02× | 1.71× |
| `alternating_sizes_tcp` | 0.139 | 1.114 | 0.151 | 7.87× | 1.07× |
| `varied_sizes_tcp` | 0.036 | 0.241 | 0.033 | 6.88× | 0.95× |
| `comment_crlf_tcp` | 0.470 | 0.673 | 1.234 | 1.48× | 2.78× |

编码耗时单位：纳秒 / 单个事件，输入 Sse 克隆不计时。sse-core 无编码 API。

| 场景 | 当前 ns | 发布版 ns | sse-core | 当前/发布版速度 |
|---|---:|---:|---:|---:|
| `small_json` | 14.7 | 93.3 | N/A | 6.48× |
| `metadata_json` | 72.1 | 115.4 | N/A | 1.62× |
| `large_ascii` | 664.7 | 1251.2 | N/A | 1.88× |
| `large_utf8` | 812.8 | 1284.4 | N/A | 1.64× |
| `empty_with_retry` | 47.5 | 96.9 | N/A | 2.03× |
